import os
import sys
WORKING_DIRECTORY=os.getcwd()
TRAIN_DATASET=WORKING_DIRECTORY+"/Datasets/train.csv"
TEST_DATASET=WORKING_DIRECTORY+"/Datasets/train.csv"
